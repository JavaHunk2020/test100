package mstream;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MapStreamDemo {
	
	public static void main(String[] args) {
		
		//10
		List<String> list=Arrays.asList("Apple","Mango","Guava","Banana","Grapes");
		Stream<String> streams=list.stream();
		
		//Map<String,Integer> ahahah=streams.collect(Collectors.toMap(t->t, s->s.length()));
		//Map<String,Integer> ahahah=streams.collect(Collectors.toMap(Function.identity(), s->s.length()));
		Map<String,Integer> ahahah=streams.collect(Collectors.toMap(Function.identity(), String::length));

		ahahah.forEach((key,value)->{
			System.out.println("Key = "+key+" , value = "+value);
		});
	}

}

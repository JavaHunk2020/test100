import java.util.function.BiPredicate;

public class BiPredicataDemo2 {
	public static void main(String[] args) {
		BiPredicate<String,Integer> predicate=(String t,Integer age) ->t.contains("te");
		
	}	
				
}
